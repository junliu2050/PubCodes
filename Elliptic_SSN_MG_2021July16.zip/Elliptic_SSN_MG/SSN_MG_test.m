%%semi-smooth newtion method
clear 
global LEVEL0 omega niu1 niu2 max_mg_it G Gz Gzz

fprintf('n\t ||err_z||\t ||err_p||\t ||r_z||  \t ||r_p|| \t (SSN-It,MG-It)\t CPU\n');
for alpha=[1e-3 1e-6]
%for alpha=1e-8   
omega=1;LEVEL0=3; %omega=1 V-cycle; omega=2 W-cycle
niu1=2;niu2=2; % smoother iterations
max_mg_it=2;%only use two V-cycle multigrid iterations
%for alpha=10.^(-8)   
fprintf('==============alpha=%1.0e===================\n',alpha);

%Example 1
lb_u=-4;ub_u=0; 
d=@(x,y) sin(2*pi*x).*sin(2*pi*y).*exp(2*x)/6;
G=@(z) z.^3+z; Gz=@(z) 3*z.^2+1; Gzz=@(z) 6*z;
%G=@(z) z.^4; Gz=@(z) 4*z.^3; Gzz=@(z) 12*z.^2;

n0=0;first=1;
for n=2.^(5:9)
h=1/n; m = n-1;
xx = linspace(0,1,n+1);  % x grid points including boundaries
yy = linspace(0,1,n+1);   % y grid points including boundaries
[Xint,Yint] = meshgrid(xx(2:end-1),yy(2:end-1));      % 2d arrays of x,y values

g_h=zeros(m,m);g_h=g_h(:);
d_h=d(Xint,Yint);d_h=d_h(:);

A=(1/h^2)*gallery('poisson',m);
maxit=50;tol=1e-8;
totalmgit=0;
tic
if(first) %coarest
    p_h=zeros(m^2,1);s_h=zeros(m^2,1);u_h=zeros(m^2,1);
else %better initial
     p_h=intp3(p_h);     s_h=intp3(s_h);         u_h=intp3(u_h); 
end
first=0;
r_z=A*s_h+G(s_h)-u_h-g_h; 
r_p=A*p_h+Gz(s_h).*p_h+s_h-d_h;
r_z00=h*norm(r_z);r_p00=h*norm(r_p);   

iter=0;
%fprintf('It=%2d\t r_z=%1.2e \t r_p=%1.2e \n',iter,r_z00,r_p00);
%fprintf('(-');
for iter=1:maxit 
    res=[r_p;r_z];
    [mgiter,dx]=ssn_MG_semilinear(s_h,p_h,alpha,lb_u,ub_u,n,res);
    totalmgit=totalmgit+mgiter;
    
    s_h=s_h-dx(1:m^2);      
    p_h=p_h-dx(m^2+1:end);
    u_h=max(lb_u,min(ub_u,p_h/alpha));
    
    r_z=A*s_h+G(s_h)-u_h-g_h; 
    r_p=A*p_h+Gz(s_h).*p_h+s_h-d_h;
    r_z0=h*norm(r_z);r_p0=h*norm(r_p);
    err_s=h*norm(dx(1:m^2)); err_p=h*norm(dx(m^2+1:end));
    %fprintf('It=%2d\t r_z=%1.2e \t r_p=%1.2e \t dx=%1.2e\n',iter,r_z0,r_p0,norm(dx,inf));
    if((r_z0+r_p0)<=tol*(max(r_z00+r_p00,1)))
     %if( h*norm(dx)<=tol)
        break
    end
end
%fprintf('-)\n');
mgtime=toc;
%compute residual
%r_z=A*s_h+G(s_h)-u_h-g_h; r_p=A*p_h+Gz(s_h).*p_h+s_h-d_h;
res_z=r_z0;
res_p=r_p0;



fprintf('%4d&\t %1.2e&\t%1.2e&\t %1.2e&\t  %1.2e&\t (%d,%d)& \t%1.2f \\\\\n',...
    n,err_s,err_p,res_z,res_p,iter,totalmgit,mgtime)
end

end

return
%  subplot(1,2,1)
%  mesh(Xint,Yint,reshape(u_h,m,m))
%  subplot(1,2,2)
%  mesh(Xint,Yint,reshape(s_h,m,m))
% subplot(2,2,3)
% mesh(Xint,Yint,s_h-s(Xint,Yint))
% subplot(2,2,4)
% mesh(Xint,Yint,u_h-u(Xint,Yint))
%mesh(Xint,Yint,p(Xint,Yint))