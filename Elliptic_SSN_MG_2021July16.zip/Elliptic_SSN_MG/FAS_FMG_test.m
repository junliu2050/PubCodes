%Borzi's FAS–MG method
clear
global LEVEL0 omega niu1 niu2
global T Tz Tzz
omega=2;niu1=2;niu2=2; LEVEL0=3;
for alpha=[1e-3 1e-6]
fprintf('==============alpha=%1.0e===================\n',alpha);
%Example 1
d=@(x,y) double(sin(2*pi*x).*sin(2*pi*y).*exp(2*x)/6);
lb_uf=@(x,y) double(-4*ones(size(x))); ub_uf=@(x,y) double(zeros(size(x)));
T=@(z) double(z.^3+z); Tz=@(z) double(3*z.^2+1); Tzz=@(z) double(6*z);

%Example 2
%  d=@(x,y) double(sin(2*pi*x).*sin(3*pi*y)); 
%  lb_uf=@(x,y) double(-.5*ones(size(x))); ub_uf=@(x,y) double(.5*ones(size(x)));
%  T=@(z) double(z.^4); Tz=@(z) double(4*z.^3); Tzz=@(z)double(12*z.^2);

%Example 3
%  d=@(x,y) double(cos(pi*x).*cos(pi*y).*exp(x)/2);
%  lb_uf=@(x,y) double(-8*ones(size(x))); ub_uf=@(x,y) double(4*ones(size(x)));
%  T=@(z) double(z.^3+z+exp(10*z)); Tz=@(z) double(3*z.^2+1+10*exp(10*z)); 
%  Tzz=@(z) double(6*z+100*exp(10*z)); 


fprintf('n\t ||z-z_d||\t||err_z||\t ||err_p|| \t ||res_z||  \t ||res_p|| \t FAS-Iter\t CPU\n');
n0=0;step=0;
for n=2.^(5:10)
    tic
h=1/n; m = n-1;
xx = linspace(0,1,n+1);   % x grid points including boundaries
yy = linspace(0,1,n+1);   % y grid points including boundaries

[Xint,Yint] = meshgrid(xx(2:end-1),yy(2:end-1));      % 2d arrays of x,y values

g_h=zeros(m,m);g_h=g_h(:);
d_h=d(Xint,Yint);d_h=d_h(:);
lb_u=lb_uf(Xint,Yint); lb_u=lb_u(:);
ub_u=ub_uf(Xint,Yint); ub_u=ub_u(:);

fineL=log2(n);mg=[];
for Level=fineL:-1:LEVEL0
    N=2^Level; hh=1/N; %%%%%%%****************** stupid to define hh as h
    mg(Level).A=(1/hh^2)*gallery('poisson',N-1);
    mg(Level).h=hh;
end
A=mg(fineL).A; 
% if(step==0)
 z_h=zeros(m^2,1);p_h=zeros(m^2,1);u_h=zeros(m^2,1);
    %step=1;
% else
%     z_h=intp3(z_h); p_h=intp3(p_h); u_h=intp3(u_h);
% end
%r_z=A*z_h-u_h-g_h; r_p=A*p_h+z_h-d_h;
%r_z00=h*norm(r_z);r_p00=h*norm(r_p);
% err_z=h*norm(z_h-zsol(:));err_u=h*norm(u_h-usol(:));err_p=h*norm(p_h-psol(:));
%     fprintf('Init\t r_z=%1.2e \t r_p=%1.2e \t e_z=%1.2e\t e_p=%1.2e\t e_u=%1.2e\n',r_z0,r_p0,err_z,err_p,err_u);
%    
 r_z=A*z_h+T(z_h)-u_h-g_h; r_p=A*p_h+Tz(z_h).*p_h+z_h-d_h;
 r_z00=h*norm(r_z);r_p00=h*norm(r_p);
%[z_h,p_h,u_h]=FAS_FMG_Cycle_semilinear(mg,z_h,p_h,u_h,d_h,g_h,fineL,niu1,niu2,alpha,lb_u,ub_u);

% err_z=h*norm(z_h-zsol(:));err_u=h*norm(u_h-usol(:));err_p=h*norm(p_h-psol(:));
%fprintf('FMG\t r_z=%1.2e \t r_p=%1.2e \n',r_z00,r_p00);
%    
maxit=50;tol=1e-8;

for iter=1:maxit 
    [z_h_new,p_h_new,u_h_new]=FAS_Cycle_semilinear(mg,z_h,p_h,u_h,d_h,g_h,fineL,niu1,niu2,alpha,lb_u,ub_u);
   err_s=h*norm(z_h_new-z_h); err_p=h*norm(p_h_new-p_h);
   z_h=z_h_new;p_h=p_h_new;u_h=u_h_new;
     
   r_z=A*z_h+T(z_h)-u_h-g_h; 
   r_p=A*p_h+Tz(z_h).*p_h+z_h-d_h;
    r_z0=h*norm(r_z);
    r_p0=h*norm(r_p);

   % fprintf('It=%2d\t r_z=%1.2e \t r_p=%1.2e \n',iter,r_z0,r_p0);
    if((r_z0+r_p0)<=tol*max(1,r_z00+r_p00))
        break
    end
end
mgtime=toc;

%compute error in residual form

res_z=r_z0;
res_p=r_p0;
err_d=h*norm(z_h-d_h);
fprintf('%4d&\t%1.8f &\t%1.2e&\t%1.2e&\t %1.2e&\t  %1.2e&\t %d& \t%1.2f \\\\\n',...
    n,err_d,err_s,err_p,res_z,res_p,iter,mgtime)

end

end
% subplot(1,2,1)
% mesh(Xint,Yint,reshape(s_h,n-1,n-1))
% subplot(1,2,2)
% mesh(Xint,Yint,reshape(u_h,n-1,n-1))
% mesh(Xint,Yint,p(Xint,Yint))