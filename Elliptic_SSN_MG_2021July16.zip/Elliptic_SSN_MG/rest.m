function [rc]=rest(r)

n=sqrt(length(r));
r=reshape(r,n,n);
%half-weighting restriction
% rc=(                      +r(1:2:end-2,2:2:end-1)                 +...
%     r(2:2:end-1,1:2:end-2)+4*r(2:2:end-1,2:2:end-1)+r(2:2:end-1,3:2:end)+...
%                            +r(3:2:end,2:2:end-1)      )/8;
% rc=rc(:);
%full weighting averaging
rc=(r(1:2:end-2,1:2:end-2)+2*r(1:2:end-2,2:2:end-1)   +r(1:2:end-2,3:2:end)+...
    2*r(2:2:end-1,1:2:end-2)+4*r(2:2:end-1,2:2:end-1)+2*r(2:2:end-1,3:2:end)+...
    r(3:2:end,1:2:end-2)   +2*r(3:2:end,2:2:end-1)        +r(3:2:end,3:2:end))/16;
rc=rc(:);
end
