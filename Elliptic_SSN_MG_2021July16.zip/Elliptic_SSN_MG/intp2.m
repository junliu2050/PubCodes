function rf=intp2(r)
% n=length(r);nH=sqrt(n);
% H=1/(nH+1);h=H/2;nh=2*nH+1;
% [xH,yH] = meshgrid((0:nH+1)*H,(0:nH+1)*H);
% [xh,yh] = meshgrid((1:nh)*h,(1:nh)*h);
% Uh=zeros(nH+2,nH+2);
% Uh(2:end-1,2:end-1)=reshape(r,nH,nH);
% % Do cubic interpolation
% uh=interp2(xH,yH,Uh,xh,yh,'linear');
% rf=uh(:);
% 
n=sqrt(length(r));
R=zeros(n+2,n+2); 
R(2:end-1,2:end-1)=reshape(r,n,n);
m=2*n+1;
rf=zeros(m,m);
rf(2:2:end-1,2:2:end-1) = R(2:end-1,2:end-1);
rf(1:2:end,2:2:end-1) = 0.5*(R(1:end-1,2:end-1) + R(2:end,2:end-1));
rf(2:2:end,1:2:end) = 0.5*(R(2:end-1,1:end-1) + R(2:end-1,2:end));
rf(1:2:end,1:2:end) = 0.25*(R(1:end-1,1:end-1)+ R(2:end,1:end-1)...
                                + R(1:end-1,2:end) + R(2:end,2:end));
rf=rf(:);

end