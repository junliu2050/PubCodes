function [z_h,p_h,u_h]=FAS_Cycle_semilinear(mg,z_h,p_h,u_h,d_h,g_h,level,pre,post,alpha,lb_u,ub_u)
%fprintf('+++++++++++++++++++Level[%d] Begin+++++++++++++++++++++\n',level);
A=mg(level).A;h=mg(level).h;
global LEVEL0 omega
global T Tz
if(level==LEVEL0) %Coarest level
    [z_h,p_h,u_h] = mg_smooth_sm(z_h,p_h,u_h,d_h,g_h,10,alpha,lb_u,ub_u,h);
else
    % presmooth
    [z_h,p_h,u_h] = mg_smooth_sm(z_h,p_h,u_h,d_h,g_h,pre,alpha,lb_u,ub_u,h);
    
    AH=mg(level-1).A;
    z_H=inject(z_h);
    p_H=inject(p_h);
    u_H=inject(u_h);
    lb_H=inject(lb_u);ub_H=inject(ub_u);
    g_H=(AH*z_H+T(z_H)-u_H)+rest(g_h-(A*z_h+T(z_h)-u_h));
    d_H=(AH*p_H+Tz(z_H).*p_H+z_H)+rest(d_h-(A*p_h+Tz(z_h).*p_h+z_h));
    
        %coarse correction
    z_H1=z_H;p_H1=p_H;u_H1=u_H;
    for j=1:omega
        [z_H1,p_H1,u_H1]=FAS_Cycle_semilinear(mg,z_H1,p_H1,u_H1,d_H,g_H,level-1,pre,post,alpha,lb_H,ub_H);    
    end
    z_h=z_h+intp2(z_H1-z_H);
    p_h=p_h+intp2(p_H1-p_H);
    u_h=u_h+intp2(u_H1-u_H);
    % postsmooth
    [z_h,p_h,u_h] = mg_smooth_sm(z_h,p_h,u_h,d_h,g_h,post,alpha,lb_u,ub_u,h);
end
%fprintf('+++++++++++++++++++Level[%d] End+++++++++++++++++++++\n',level);
end




