function uh=intp3(uH)
n=length(uH);nH=sqrt(n);
H=1/(nH+1);h=H/2;
[xH,yH] = meshgrid((0:nH+1)*H,(0:nH+1)*H);
[xh,yh] = meshgrid((1:2*(nH+1)-1)*h,(1:2*(nH+1)-1)*h);

UH=zeros(nH+2,nH+2);
UH(2:nH+1,2:nH+1)=reshape(uH,nH,nH);

% Do cubic interpolation
Uh=interp2(xH,yH,UH,xh,yh,'cubic');
uh=Uh(:);
end