function [z_h,p_h,u_h]=mg_smooth_sm(z_h,p_h,u_h,d_h,g_h,nv,alpha,LB,UB,h)
%has to be in component, or else can't reduce residual to zero
global T Tz Tzz
n=sqrt(length(z_h));
Y=zeros(n+2,n+2); 
P=zeros(n+2,n+2); 
U=zeros(n+2,n+2); 
D=zeros(n+2,n+2); 
G=zeros(n+2,n+2);
Y(2:end-1,2:end-1)=reshape(z_h,n,n);
P(2:end-1,2:end-1)=reshape(p_h,n,n);
U(2:end-1,2:end-1)=reshape(u_h,n,n);
D(2:end-1,2:end-1)=reshape(d_h,n,n);
G(2:end-1,2:end-1)=reshape(g_h,n,n);

%notice X(i,j)=x(i,j)
for k=1:nv
    TY=T(Y); TzY=Tz(Y); TzzY=Tzz(Y); %vectorize the function calling to speed up
for i=2:n+1
    for j=2:n+1
        Cy=-((1/h^2)*(Y(i-1,j)+Y(i+1,j)+Y(i,j-1)+Y(i,j+1))+G(i,j));
        Cp=-((1/h^2)*(P(i-1,j)+P(i+1,j)+P(i,j-1)+P(i,j+1))+D(i,j));
             %update u(i,j)
        rp=Cp+(4/h^2)*P(i,j)+TzY(i,j)*P(i,j)+Y(i,j);
        Ubar=(alpha+(4/h^2+TzY(i,j))^2\(TzzY(i,j)*P(i,j)+1))\...
            (P(i,j)-(4/h^2+TzY(i,j))^2\...
            ((-(TzzY(i,j)*P(i,j)+1))*(Cy+(4/h^2)*Y(i,j)+TY(i,j))+(4/h^2+TzY(i,j))*rp));
        %projection of u(i,j)
        U(i,j)=max(LB((i-2)*n+j-1),min(UB((i-2)*n+j-1),Ubar));
      %update y(i,j)
        ry=Cy+(4/h^2)*Y(i,j)+TY(i,j)-U(i,j); 
        Y(i,j)=Y(i,j)-(4/h^2+TzY(i,j))\ry;
        %update p(i,j)
         rp=Cp+(4/h^2)*P(i,j)+TzY(i,j)*P(i,j)+Y(i,j);
        P(i,j)=P(i,j)-((4/h^2+TzY(i,j))^2)\(-(TzzY(i,j)*P(i,j)+1)*ry+(4/h^2+TzY(i,j))*rp);
    end
end
end

z_h=Y(2:end-1,2:end-1);z_h=z_h(:);
p_h=P(2:end-1,2:end-1);p_h=p_h(:);
u_h=U(2:end-1,2:end-1);u_h=u_h(:);

