function [iter,x]=ssn_MG_semilinear(s_h,p_h,alpha,lb_u,ub_u,n,b)
fineL=log2(n);m=n-1;
xmin=0;xmax=1;
%Setup operators
mg=[];
global LEVEL0 niu1 niu2 max_mg_it Gz Gzz
%omega=2;niu1=4;niu2=4;LEVEL0=3;
Ik=(p_h>alpha*lb_u)&(p_h<alpha*ub_u); 
for Level=fineL:-1:LEVEL0
 nn=2^Level; hh=(xmax-xmin)/nn;
 mg(Level).A=(1/hh^2)*gallery('poisson',nn-1)+spdiags(Gz(s_h),0,(nn-1)^2,(nn-1)^2);
 mg(Level).D=-Ik/alpha;
 mg(Level).E=1+Gzz(s_h).*p_h;
 Ik=rest(Ik);
 p_h=rest(p_h);
 s_h=rest(s_h);
end


% 
h=1/2^fineL;
A=mg(fineL).A; D=mg(fineL).D;E=mg(fineL).E;
x=zeros(size(b));
%h=hx;
%maxit=10;
%tol=1e-8; 
x1=x(1:m^2);x2=x(m^2+1:end);
r0=h*norm(b-[E.*x1+A*x2;A*x1+D.*x2]);rk=r0;
%err0=[];
%one FMG iteration
iter=0;
%x=full_mg_2d(mg,b,fineL,niu1,niu2,'cJAC'); %FMG gives better initials
%iter=iter+1;
% 
while((iter<max_mg_it))%&&(rk>=max(1,r0)*tol)
     iter=iter+1;
     x=mg_iter_2d(mg,x,b,fineL,niu1,niu2,'cJAC');% 'cGS'
     %x1=x(1:m^2);x2=x(m^2+1:end);
     %rk=h*norm(b-[E.*x1+A*x2;A*x1+D.*x2]);
     %fprintf('>>>>>>>>>>>iter=%d\t, rk=%1.2e\n',iter,rk);
end
%plot([1:iter],log10(err0),'-o');
%res=err0(end);
%err=hx*norm(S0(:)-x);
% subplot(2,1,1)
% plot(xgrid,sold0(xgrid))
% subplot(2,1,2)
% plot(xgrid,x0(1:N+1))
%u=mg(fineL).A\rhs;
end


function [x]=full_mg_2d(mg,b,level,pre,post,smoother)
A=mg(level).A;D=mg(level).D;
N=size(A,1);E=speye(N);
global LEVEL0;
if(level==LEVEL0) %Coarest level
    x=[spdiags(E,0,N,N) A;A spdiags(D,0,N,N)]\b; 
else
    b1=b(1:N);b2=b(N+1:end);
    rH=[inject(b1);inject(b2)];
    xH=full_mg_2d(mg,rH,level-1,pre,post,smoother);
    NH=((sqrt(N)-1)/2)^2;
    xH1=xH(1:NH);xH2=xH(NH+1:end);
    x=[intp3(xH1);intp3(xH2)];
end
x=mg_iter_2d(mg,x,b,level,pre,post,smoother);
end

function [x]=mg_iter_2d(mg,x0,b,level,pre,post,smoother)
%fprintf('+++++++++++++++++++Level[%d] Begin+++++++++++++++++++++\n',level);
A=mg(level).A;D=mg(level).D;E=mg(level).E;
N=size(A,1);
global LEVEL0;
global omega
if(level==LEVEL0) %Coarest level
    x=[spdiags(E,0,N,N) A;A spdiags(D,0,N,N)]\b; 
else
   % presmooth 
   %fprintf('Level[%d],Before Presmooth res=%1.2e\n',level,norm(b-A*x0));
   x = mg_smooth(E,A,D,x0,b,pre,smoother);
   %fprintf('Level[%d],After Presmooth res=%1.2e\n',level,norm(b-A*x));
   % Restrict residual
   x1=x(1:N);x2=x(N+1:end);
   r = b - [E.*x1+A*x2;A*x1+D.*x2];
   rc =[rest(r(1:N)); rest(r(N+1:end))];
   % coarse grid correction
   %V-cycle
   cc=zeros(size(rc));
   for j=1:omega
        cc = mg_iter_2d(mg,cc,rc,level-1,pre,post,smoother);
   end
   NH=((sqrt(N)-1)/2)^2;
   x = x + [intp2(cc(1:NH));intp2(cc(NH+1:end))];
   % postsmooth
   %fprintf('Level[%d],Before Postsmooth res=%1.2e\n',level,norm(b-A*x));
   x = mg_smooth(E,A,D,x,b,post,smoother);
   %fprintf('Level[%d],After Postsmooth res=%1.2e\n',level,norm(b-A*x));
end
%fprintf('+++++++++++++++++++Level[%d] End+++++++++++++++++++++\n',level);
end
function [x]=mg_smooth(E,A,D,x0,b,nv,smoother)
x=x0;N=size(A,1);
%Jacobi Smoother
switch smoother
case 'cJAC'
    w=2/3;   dA=diag(A);
    for k = 1:nv
        x1=x(1:N);x2=x(N+1:end);
        r = b - [E.*x1+A*x2;A*x1+D.*x2];
        r1=r(1:N); r2=r(N+1:end);
        s=(D-E.\(dA.^2)).\(-dA.*(E.\r1)+r2);
        x=x + w*[E.\r1-E.\(dA.*s);s];          
    end
case 'cGS'
    tA=tril(A);
    for k = 1:nv
        x1=x(1:N);x2=x(N+1:end);
        r = b - [E.*x1+A*x2;A*x1+D.*x2];
        r1=r(1:N); r2=r(N+1:end);
        AEA=-tA*bsxfun(@ldivide,E,tA);
        AEA(1:N+1:N^2)=D+AEA(1:N+1:N^2)';
        s=AEA\(-tA*(E.\r1)+r2);
        x=x + [E.\r1-E.\(tA*s);s];          
    end
end
end
 



