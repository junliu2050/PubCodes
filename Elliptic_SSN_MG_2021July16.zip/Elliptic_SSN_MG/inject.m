function [rc]=inject(r)
%rc=rest(r);
 n=length(r);N=sqrt(n)+1;
 r=reshape(r,N-1,N-1);
 rc=r(2:2:end-1,2:2:end-1);
 rc=rc(:);

end