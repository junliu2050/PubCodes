%function LinearWaveOPT_2D_MatrixSystem_ControlConstraints()
%2-dimensional case 
clear
%clc
global gamma Lh Ia Ib Pre lam lam0 lam1 D1 D2 Ix Lh_C I0 Da Lam dS dSinv bD
maxL=8; % increase for larger mesh
scheme=1; 
tol=1e-7;maxit=50;  Kmax=50;
list={'alf-Circulant','Circulant','MatchingFastScaled'};
for kk=1:3
    pretype=list{kk}; %'MatchingFast','ConstraintFast'
    fprintf('==============Precoditioner [%s]=============\n',pretype);
    %%(B) Set the problem data: rhs, exact solutions, parameters
    T=2;
    for gamma=10.^[0:-2:-10]
        fprintf('==============Gamma [%e]=============\n',gamma);
        Ua=-10; Ub=-5; %adjust the box constraints
        %Based on Example 2
        %         y_sol=@(x1,x2,t)  exp(t).*sin(pi*x1).*sin(pi*x2);
        %         y_t1=@(x1,x2) sin(pi*x1).*sin(pi*x2); %derivative initial condition
        %         p_sol=@(x1,x2,t)  (t-T).^2.*sin(pi*x1).*sin(pi*x2);
        %         f=@(x1,x2,t) (1+2*pi^2)*y_sol(x1,x2,t)-max(Ua,min(Ub,p_sol(x1,x2,t)/gamma));
        %         yd=@(x1,x2,t) 2*sin(pi*x1).*sin(pi*x2)+2*pi^2*p_sol(x1,x2,t)+y_sol(x1,x2,t);
        %Based on Example 3
        %         y_sol=@(x1,x2,t)  cos(pi*t).*sin(pi*x1).*sin(pi*x2);
        %         y_t1=@(x1,x2) zeros(size(x1)); %derivative initial condition
        %         p_sol=@(x1,x2,t)  (t-T).^2.*sin(pi*x1).*sin(pi*x2);
        %         f=@(x1,x2,t) pi^2*y_sol(x1,x2,t)-max(Ua,min(Ub,p_sol(x1,x2,t)/gamma));
        %         yd=@(x1,x2,t) 2*sin(pi*x1).*sin(pi*x2)+2*pi^2*p_sol(x1,x2,t)+y_sol(x1,x2,t);
        %Example 4 with non-trig functions in space
        y_sol=@(x1,x2,t)  log(t+1).*(exp(x1)-1).*(exp(x1)-exp(1)).*(exp(x2)-1).*(exp(x2)-exp(1));
        y_t1=@(x1,x2) (exp(x1)-1).*(exp(x1)-exp(1)).*(exp(x2)-1).*(exp(x2)-exp(1)); %derivative initial condition
        p_sol=@(x1,x2,t)  (t-T).^2.*(exp(x1)-1).*(exp(x1)-exp(1)).*(exp(x2)-1).*(exp(x2)-exp(1));
        f=@(x1,x2,t) -(1./(t+1).^2).*(exp(x1)-1).*(exp(x1)-exp(1)).*(exp(x2)-1).*(exp(x2)-exp(1))...
            -log(t+1).*((4*exp(2*x1)-exp(x1+1)-exp(x1)).*(exp(x2)-1).*(exp(x2)-exp(1))+...
            (4*exp(2*x2)-exp(x2+1)-exp(x2)).*(exp(x1)-1).*(exp(x1)-exp(1)))-max(Ua,min(Ub,p_sol(x1,x2,t)/gamma));
        yd=@(x1,x2,t) 2*(exp(x1)-1).*(exp(x1)-exp(1)).*(exp(x2)-1).*(exp(x2)-exp(1))...
            -(t-T).^2.*((4*exp(2*x1)-exp(x1+1)-exp(x1)).*(exp(x2)-1).*(exp(x2)-exp(1))+...
            (4*exp(2*x2)-exp(x2+1)-exp(x2)).*(exp(x1)-1).*(exp(x1)-exp(1)))+y_sol(x1,x2,t);
        
        nxlist=2.^(3:maxL);%nx=ny
        ntlist=2.^(3:maxL)+1;
        levmax=length(nxlist);
        fprintf('(Nx,Nx,Nt)\t\t err_y\t\t order\t err_p\t\t order\t It_Nwt\t It_LCP\t It_GM \t CPU\n');
        
        y_err_0=0;p_err_0=0;
        for s=1:levmax
            nx=nxlist(s); nt=ntlist(s);
            %nx=Nx(levmax-1);%nt=Nt(levmax-1);%fix tau
            m=nx-1;dt=T/nt; h=1/nx; %xx = linspace(0,1,nx+1)';
            [Xint,Yint,Tgd] = meshgrid(h:h:1-h,h:h:1-h,0:dt:T); %inner grid points
            %construct target yd, exact y, exact p, independent of scheme
            yd_h=yd(Xint,Yint,Tgd);
            ysol=y_sol(Xint,Yint,Tgd);
            psol=p_sol(Xint,Yint,Tgd);
            f_h=f(Xint,Yint,Tgd);
            
            L=-(1/h^2)*gallery('poisson',m); %laplacian \Delta
            %Lap=L;
            b_y=f_h;      b_p=yd_h;
            Ly0=reshape(L*reshape(ysol(:,:,1),m^2,1),m,m);
            %set right hand side according to scheme
            b_y(:,:,1)=f_h(:,:,1)/2+y_t1(Xint(:,:,1),Yint(:,:,1))/dt+ysol(:,:,1)/dt^2;
            b_y(:,:,2)=f_h(:,:,2)-ysol(:,:,1)/dt^2+0.5*Ly0;
            b_p(:,:,end)=b_p(:,:,end)/2;
            b_y=b_y(:);b_p=b_p(:);
            clear yd_h f_h Ly0
            %Scheme based discretization
            [Lh,Ia,Ib]=discretizeSystem(nx,nt,T,scheme); %coefficient matrix
            I0=speye(size(Ia)); Ix=speye(m^2);
            switch pretype
                case {'MatchingFastScaled','MatchingScaled'}
                    L2=[Ib/sqrt(gamma) Lh';Lh -Ia/sqrt(gamma)]; %rescaled
                    fb=[b_p(m^2+1:end);sqrt(gamma)*b_y(1:end-m^2)];
                    fh=b_p(m^2+1:end);gh=sqrt(gamma)*b_y(1:end-m^2);
                case 'alf-Circulant'
                    L2=[Lh -Ia/gamma;Ib Lh']; %rescaled
                    %fb=[b_y(1:end-m^2);b_p(m^2+1:end)];
                    fh=b_y(1:end-m^2);gh=b_p(m^2+1:end);
                    %define preconditioner matrices
                    Nt=nt; alf=0.1;
                    Da=alf.^((0:Nt-1)'/Nt);
                    c1=zeros(Nt,1); c1(1:3)=[1 -2 1]; D1=fft(Da.*c1);
                    c2=zeros(Nt,1); c2(1:3)=[1 0 1]; D2=fft(Da.*c2);
                    Lam=D1./D2;
                case  'Circulant'
                    L2=[Lh -Ia/gamma;Ib Lh']; %rescaled
                    %fb=[b_y(1:end-m^2);b_p(m^2+1:end)];
                    fh=b_y(1:end-m^2);gh=b_p(m^2+1:end);
                    %define preconditioner matrices
                    Nt=nt;  
                    c1=zeros(Nt,1); c1(1:3)=[1 -2 1]; D1=fft(c1);
                    c2=zeros(Nt,1); c2(1:3)=[1 0 1]; D2=fft(c2);
                    Lam=D1./D2;
                    R1=-(dt^2)./(D2);
                    R2=(dt^2)./conj(D2);
                    S1=0.5*(1./R1).*(Lam-conj(Lam)+sqrt((Lam-conj(Lam)).^2+4*R1.*R2));
                    S2=-0.5*(1./R2).*(Lam-conj(Lam)+sqrt((Lam-conj(Lam)).^2+4*R1.*R2));                    
                    dS1=spdiags(S1,0,Nt,Nt);dS2=spdiags(S2,0,Nt,Nt);
                    It=speye(Nt); Ix=speye(m^2);
                    dS=[It,dS2;dS1,It].';
                    bD=[Lam+R1.*S1;conj(Lam)+R2.*S2];
                    dSinv=dS'/2;
                    
                otherwise
                    L2=[Ib Lh';Lh -Ia/gamma]; %whole system
                    fb=[b_p(m^2+1:end);b_y(1:end-m^2)]; %RHS
            end
            tic
            %setup for quasi-Newton iterations
            Nt=nt;  Nx=m^2; E=ones(Nx,1);Q=[Ix;-Ix];  qh=[-Ua*E;Ub*E]; D=Q*Q'; %semidefinite only
            It=speye(Nt);hI=speye(Nt);hI(1,1)=0.5;cI=speye(Nt);cI(Nt,Nt)=0.5;
            IQ=kron(hI,transpose(Q));
            clear E
            %--------------- quasi-Newton iteration--------------
            dimPhi=size(Q,1);Nt=nt;itlcptotal=0;itgmres=0;
            Phi=zeros(dimPhi,Nt);Yk=zeros(Nx,Nt);Pk=zeros(Nx,Nt);
            
            b=[IQ*Phi(:)+fh;gh];
            Res_0=norm(b);
            Jac=[Lh -Ia;Ib Lh']; %(4.8b) 
            %%Preconditioner setup
            %z=L2\fb; %sparse direct solver
            %iter=0;
            Pre.TT=speye(m^2)/dt^2-0.5*L;
            Pre.nt=nt; Pre.dt=dt; Pre.h=h;
            %for fft poisson solver for solving Pre.TT
            lambda = (4/h^2) * (sin(((1:m)*pi) / (2*m + 2))).^2 ; %eigvalues of -Lap
            [lamx, lamy] = meshgrid(lambda,lambda);
            %for Circulant preconditioner use
            lam=(lamx+lamy); 
            clear lambda lamx lamy
            aparams=struct('Afun',@(x,pA) Jac*x);
            mparams=struct('Mfun',@(r,pA,pB) prefun(r,pretype));
            for k=1:Kmax
                %need to update rhs term
                for j=1:Nt
                    q=Q*Pk(:,j)/gamma+qh;                     
                    [Phi(:,j),itlcp] = LCP(D,q);%even faster
                    itlcptotal=[itlcptotal;itlcp];
                end
                b=[IQ*Phi(:)+fh;gh];
                YP_k=[Yk(:); Pk(:)];
                %YP_k1=YP_k-(Jac\(M*YP_k-b));
                % zk=Jac\(M*YP_k-b);
                %use our preconditioner here, case gam=1, no need to rescale
                [zk,~,iter]=gmres_r(aparams,mparams,(L2*YP_k-b), [sqrt(tol),maxit],0);
                %warning('off','all')
                %[zk,~,~,iter,resvec]=gmres(Jac,(M*YP_k-b),[],sqrt(Tol),maxit,@prefun);
                
                itgmres=[itgmres;iter(end)];
                % fprintf('>>>>>>>>k=%d \t norm((M*YP_k-b))=%1.2e\n',k,norm(M*YP_k-b));
                
                YP_k1=YP_k-zk;
                
                Yk1=YP_k1(1:Nt*Nx);
                Pk1=YP_k1(Nt*Nx+1:end);
                %Err_Y=norm(Yk-invVec(Yk1,Nx,Nt),inf);
                %fprintf('%d-WR iteration, Error=%2.14f\n',k,norm(Err_Y,inf));
                Yk=reshape(Yk1,Nx,Nt);
                Pk=reshape(Pk1,Nx,Nt);
                Res_k=norm(L2*YP_k-b);
                %fprintf('%d-quasi Newton iteration, Rel.Res.=%2.2e\n',k,Res_k);
                if (Res_k/Res_0<=tol||norm(YP_k1-YP_k)<=tol)
                    break;
                end
            end
            
            tsolving=toc;
            
            %%(E) Measure errors:
            mm=m^2;
            N=mm*(nt+1);
            z=YP_k1;
            y0=ysol(:,:,1);pN=psol(:,:,end);
            
            x=[y0(:);z;pN(:)];
            y_h=x(1:N);     p_h=x(N+1:end);
            
            %L^infty in time and L^2 in space
            y_err_t=sqrt(h^2*sum(sum(abs(reshape(y_h,m,m,nt+1)-ysol).^2,1),2));
            p_err_t=sqrt(h^2*sum(sum(abs(reshape(p_h,m,m,nt+1)-psol).^2,1),2));
            y_err=max(y_err_t);
            p_err=max(p_err_t);
            fprintf('&(%d,%d,%d)&\t %1.2e& %1.1f &\t %1.2e & %1.1f &\t\t %d&\t%d&\t%d&\t %1.1f \\\\\n',...
                nx,nx,nt,y_err,log2(y_err_0/y_err),p_err,log2(p_err_0/p_err),k,round(mean(itlcptotal)),round(mean(itgmres)),tsolving)
            y_err_0=y_err;p_err_0=p_err;
            clear L x y_h ysol p_h psol b b_y b_p
        end
    end
end
return
%plot errors
E_y=reshape(y_h-ysol,m,nt+1);
E_p=reshape(p_h-psol,m,nt+1);
tt=(0:dt:T);
subplot(2,1,1)
mesh(tt,Xint,E_y); xlabel('time');ylabel('space');
subplot(2,1,2)
mesh(tt,Xint,E_p); xlabel('time');ylabel('space');


function z=prefun(r,pretype)
global gamma Lh Ia Ib Pre dS bD D2 Lap Ix dSinv Lh_C I0 Da Lam
N=length(r)/2;
r1=r(1:N); r2=r(N+1:end);
switch pretype
    case {'Circulant','CirculantNoScale'}
        %z2=[Lh_C -I0/sqrt(gamma);I0/sqrt(gamma) Lh_C']\r; %need faster codes
        
        %direct implementation using fft/ifft
        Nt=Pre.nt; Nx=N/Pre.nt; dt=Pre.dt;
        Res=reshape(r,Nx,2*Nt);
        
        V1a=[fft(Res(:,1:Nt).')./D2;fft(Res(:,Nt+1:end).')./conj(D2)].';
        %no reshape, this can be computed in parallel, Shifted linear systems
        V1=V1a*dSinv;  %use explicit inverse
        for n=1:2*Nt
            %V1(:,n)=(bD(n)*Ix/dt^2-0.5*Lap)\V1(:,n); %replace by fast solver
            V1(:,n)=bdiagsolve(2*V1(:,n),-1,2*bD(n)/dt^2); %use fast DST
        end
        Res2=V1*dS;
        z=reshape([ifft(Res2(:,1:Nt).');ifft(Res2(:,Nt+1:end).')].',Nx*2*Nt,1);
        z=real(z);
        %norm(z2-z,inf)
    case {'alf-Circulant'}
        %z2=[Lh_C -I0/sqrt(gamma);I0/sqrt(gamma) Lh_C']\r; %need faster codes
        
        %direct implementation using fft/ifft
        Nt=Pre.nt; Nx=N/Pre.nt; dt=Pre.dt;
        Res=reshape(r,Nx,2*Nt);
        
        V1=[fft(Da.*(Res(:,1:Nt).'))./D2;fft(Da.\(Res(:,Nt+1:end).'))./conj(D2)].';
        for n=1:Nt
            %V1(:,n)=(bD(n)*Ix/dt^2-0.5*Lap)\V1(:,n); %replace by fast solver
            V1(:,n)=bdiagsolve(2*V1(:,n),-1,2*Lam(n)/dt^2); %use fast DST
            V1(:,n+Nt)=bdiagsolve(2*V1(:,n+Nt),-1,2*conj(Lam(n))/dt^2); %use fast DST
        end
        z=reshape([Da.\ifft(V1(:,1:Nt).');Da.*ifft(V1(:,Nt+1:end).')].',Nx*2*Nt,1);
        z=real(z);
        %norm(z2-z,inf)
     case 'MatchingFastScaled'
        gam=1;
        m=N/Pre.nt;
        r2=r2/sqrt(gam);
        r1=r1+gam*Lh'*(Ia\r2);
        r1=Ia*flip(fftbacksolve(flip(r1),m));
        r1=fftbacksolve(r1,m);
        
        r2=-gam*(Ia\r2);
        r2=(Ia\(Lh*r1))+r2;
        z=[r1/sqrt(gam);r2];     
    otherwise
        z=r; %no preconditioning
end
end

function z1=fftbacksolve(r1,m)
global Pre
z1=r1;
z1(1:m)=bdiagsolve(2*r1(1:m),1); % solve 1st block
r1(m+1:2*m)=r1(m+1:2*m)+(2/Pre.dt^2)*z1(1:m);
r1(2*m+1:3*m)=r1(2*m+1:3*m)-Pre.TT*z1(1:m);
%
for k=2:Pre.nt-2
    idx=((k-1)*m+1:k*m)';
    z1(idx)=bdiagsolve(2*r1(idx),0);
    r1(idx+m)=r1(idx+m)+(2/Pre.dt^2)*z1(idx);
    r1(idx+2*m)=r1(idx+2*m)-Pre.TT*z1(idx);
end
z1(idx+m)=bdiagsolve(2*r1(idx+m),0);%last 2 solve
r1(idx+2*m)=r1(idx+2*m)+(2/Pre.dt^2)*z1(idx+m);
z1(idx+2*m)=bdiagsolve(2*r1(idx+2*m),1);
end

function u=bdiagsolve(b,flag,lamk)
%2D FFT
global lam0 lam1 lam
%solve Del2(u)=b
[m, n] = size(b);
% make sure we have a square grid
if (m ~= n) % assume input the vectorized
    b=full(reshape(b,sqrt(m),sqrt(m)));
    n=sqrt(m);
end
%b_bar=fast_dst(fast_dst(b).').';
b_bar=dst(dst(b).').';
% next we can solve for u_bar, vectorized version
switch flag
    case 1
        u_bar=b_bar./lam0;%first and last block
    case 0
        u_bar=b_bar./lam1;%inner block
    case -1
        u_bar=b_bar./(lam+lamk);
end
%u=fast_dst(fast_dst(u_bar).').';
u=idst(idst(u_bar).').';
if (m~=n) % to confort with input format
    u=u(:);
end
end

%module functions
function [A,B,C,K]=discretizeSystem(nx,nt,T,scheme)
%not including y(t=0) and p(t=T)
dt=T/nt;
h=1/nx; m = nx-1; %m for inner points
mm=m^2;
N=mm*(nt);%whole system size,
e_t=ones(nt,1); %e_2=ones(N_2,1);

B=blkdiag(speye(mm)/2,speye(N-mm));
C=blkdiag(speye(N-mm),speye(mm)/2);
I=speye(mm);
L=I+0.5*(dt^2/h^2)*gallery('poisson',m); % central finite difference for second derivative in space

A0=spdiags([e_t e_t],[-2 0],nt,nt);
B0=spdiags([e_t],[-1],nt,nt);
%construct circulant block of L
E=A0; E(1,end-1)=1; E(2,end)=1;
F=B0; F(1,end)=1;
A=(kron(A0,L)-kron(B0,2*I))/dt^2;
K=(kron(E,L)-kron(F,2*I))/dt^2;
end