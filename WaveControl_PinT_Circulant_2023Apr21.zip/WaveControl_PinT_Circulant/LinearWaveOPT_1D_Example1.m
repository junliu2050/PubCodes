%function LinearWaveOPT_1D_MatrixSystem()
%%One-dimensional case
clear
global gamma Lh I0 Ia Ib Pre Lh_C Lap  dS bD D2 Ix dSinv theta ct st
maxL=8; % increase for larger mesh
scheme=1; %implicit scheme
tol=1e-7;maxit=50;
%uncomment to choose a preconditioner
%pretype='MatchingFastScaled'; %MSC preconditioner
%pretype='Circulant'; %Circulant preconditioner
%pretype='None'; %No preconditioner
list={'None','Circulant','MatchingFastScaled'};
for kk=2:3
    pretype=list{kk};
    %%(B) Set the problem data: rhs, exact solutions, parameters
    T=2;
    %gamma=1e-2;
    fprintf('-----------------preconditioner=[%s]---------\n',pretype);

    fprintf('grid\t gam\t\terr_y\t order \t\t err_p\t order \t\t iter\t CPU\t Cond\n')
    itvec=[];
    gamvec=10.^[-1:-1:-4];

    for gamma=gamvec
        fprintf('==============Gamma [%e]=============\n',gamma);

        %Example 1
        y_sol=@(x,t) sin(pi*x).*cos(pi*t); p_sol=@(x,t) sin(pi*x).*(exp(t)-exp(T)).^2;
        y_t1=@(x) zeros(size(x)); %derivative initial condition
        f=@(x,t)  -pi^2*sin(pi*x).*cos(pi*t)+pi^2*sin(pi*x).*cos(pi*t)-p_sol(x,t)/gamma;
        yd=@(x,t)  2*(2*exp(2*t)-exp(T+t)).*sin(pi*x)+pi^2*sin(pi*x).*(exp(t)-exp(T)).^2+y_sol(x,t);
        %Example 3 without control constraints
        %     y_sol=@(x,t) sin(pi*x).*cos(pi*t);    p_sol=@(x,t) sin(pi*x).*(t-T).^2;
        %     y_t1=@(x) zeros(size(x)); %derivative initial condition
        %     f=@(x,t)  -p_sol(x,t)/gamma;
        %     yd=@(x,t)  2*sin(pi*x)+pi^2*sin(pi*x).*(t-T).^2+y_sol(x,t);

        Nxvec=2.^(5:maxL);%nx=ny
        Ntvec=2.^(5:maxL)+1;

        levmax=length(Nxvec);
        y_err_0=0;p_err_0=0;

        fprintf('\n');
        for s=1:levmax
            nx=Nxvec(s);nt=Ntvec(s); m=nx-1;
            dt=T/nt; h=1/nx; %xx = linspace(0,1,nx+1)'; Xint = xx(2:end-1);

            xx=h:h:1-h;tt=0:dt:T;
            [XX,TT] = ndgrid(xx,tt);
            ysol=y_sol(XX,TT);     psol=p_sol(XX,TT);
            yd_h=yd(XX,TT);     f_h=f(XX,TT);
            b_y=f_h;      b_p=yd_h;
            L=(1/h^2)*gallery('tridiag',m,1,-2,1);Lap=L;
            Dh=speye(m)/dt^2-0.5*L;
            %set right hand side according to scheme
            b_y(:,1)=f_h(:,1)/2+y_t1(xx')/dt + ysol(:,1)/dt^2;
            b_y(:,2)=f_h(:,2)-Dh*ysol(:,1);
            b_p(:,end)=b_p(:,end)/2;

            b_y=b_y(:);b_p=b_p(:);
            %coefficient matrix
            [Lh,Ia,Ib,Lh_C]=discretizeSystem(nx,nt,T,scheme);
            %PC=[Ib Lh_C';Lh_C -Ia/gamma];
            I0=speye(size(Ia));
            switch pretype
                case {'MatchingFastScaled'}
                    L2=[Ib/sqrt(gamma) Lh';Lh -Ia/sqrt(gamma)]; %rescaled
                    fb=[b_p(m+1:end);sqrt(gamma)*b_y(1:end-m)];
                case {'Circulant','None'}
                    %circulant preconditioning
                    L2=[Lh -Ia/sqrt(gamma);Ib/sqrt(gamma) Lh']; %rescaled
                    fb=[sqrt(gamma)*b_y(1:end-m);b_p(m+1:end)];
                    %K2=[Lh_C -I0/sqrt(gamma);I0/sqrt(gamma) Lh_C'];
                    %define preconditioner matrices
                    Nt=nt;
                    c1=zeros(Nt,1); c1(1:3)=[1 -2 1]; D1=fft(c1);
                    c2=zeros(Nt,1); c2(1:3)=[1 0 1]; D2=fft(c2);
                    %
                    %simplified formulas
                    %D1=conj(1+exp(4*pi*1i*(0:Nt-1)'/Nt)-2*exp(2*pi*1i*(0:Nt-1)'/Nt));
                    %D1=conj((1-exp(2*pi*1i*(0:Nt-1)'/Nt)).^2);
                    %D2=conj(1+exp(4*pi*1i*(0:Nt-1)'/Nt));

                    Lam=D1./D2; %Lam is actually real as below
                    %Lam=1-1./cos(2*pi*(0:Nt-1)'/Nt);
                    E1=Lam;
                    E4=E1;
                    E2=-(dt^2/sqrt(gamma))./(D2);
                    E3=(dt^2/sqrt(gamma))./conj(D2);
                    EE=(sqrt(4*E2.*E3));
                    S1=0.5*(1./E2).*EE;
                    S2=-0.5*(1./E3).*EE;
                    dS1=spdiags(S1,0,Nt,Nt);dS2=spdiags(S2,0,Nt,Nt);
                    It=speye(Nt); Ix=speye(m);
                    dS=[It,dS2;dS1,It].';
                    bD=[E1+0.5*EE;E4-0.5*EE];
                    dSinv=dS'/2;

                otherwise
                    L2=[Ib Lh';Lh -Ia/gamma]; %whole system
                    fb=[b_p(m+1:end);b_y(1:end-m)]; %RHS
            end
            %%(D) Call linear solver
            tic
            %z=L2\fb; %direct solver
            Pre.TT=Dh; Pre.nt=nt; Pre.dt=dt;
            aparams=struct('Afun',@(x,pA) L2*x);
            mparams=struct('Mfun',@(r,pA,pB) prefun(r,pretype));

            [z,flag,iter,error]=gmres_r(aparams,mparams,fb, [tol,maxit],0);
            % [z,flag,~,iter,error]=gmres(L2,fb,[],tol,maxit,@(r) prefun(r,pretype));
            iter=iter(end);
            tsolving=toc;
            itvec=[itvec;iter];

            y0=ysol(:,1);pN=psol(:,end);
            N=m*(nt+1);
            switch pretype
                case {'None','Circulant','MatchingFastScaled'}
                    x=[sqrt(gamma)*y0;z;pN];
                    y_h=x(1:N)/sqrt(gamma);     p_h=x(N+1:end);
                otherwise
                    x=[y0;z;pN];
                    y_h=x(1:N);     p_h=x(N+1:end);
            end
            Y_h=reshape(y_h,m,nt+1);
            P_h=reshape(p_h,m,nt+1);
            %%(E) Measure errors: compute errors over grid points
            %L^infty in time and L^2 in space
            y_err_t=sqrt(h*sum(abs(Y_h-ysol).^2));
            p_err_t=sqrt(h*sum(abs(P_h-psol).^2));
            y_err=max(y_err_t);
            p_err=max(p_err_t);

            fprintf('&(%4d,%4d)\t&\t %1.1e& %1.1f &\t\t %1.1e & %1.1f&\t\t %d&\t %1.1f \\\\\n',...
                nx,nt,y_err,log2(y_err_0/y_err),p_err,log2(p_err_0/p_err),iter,tsolving )
            y_err_0=y_err;p_err_0=p_err;

        end
    end
end

function z=prefun(r,pretype)
global gamma Lh I0  Ia Ib Pre dS bD D2 Lap Ix dSinv
N=length(r)/2;
r1=r(1:N); r2=r(N+1:end);
switch pretype
    case {'Circulant'}
        %direct implementation using fft/ifft
        Nt=Pre.nt; Nx=N/Pre.nt; dt=Pre.dt;
        Res=reshape(r,Nx,2*Nt);
        V1a=[fft(Res(:,1:Nt).')./D2;fft(Res(:,Nt+1:end).')./conj(D2)].';

        %no reshape, this can be computed in parallel, Shifted linear systems
        V1=V1a*dSinv;  %use explicit inverse
        for n=1:2*Nt
            V1(:,n)=(bD(n)*Ix/dt^2-0.5*Lap)\V1(:,n); %tridiagonal solver, fast
        end
        Res2=V1*dS;

        z=reshape([ifft(Res2(:,1:Nt).');ifft(Res2(:,Nt+1:end).')].',Nx*2*Nt,1);
        %fprintf('%e\n',norm(z-z2,inf))
        %norm(imag(z(:)),inf)
        z=real(z);
    case 'MatchingFastScaled' %combine scale into matching preconditioner
        m=N/Pre.nt;
        r2=r2/sqrt(gamma);
        r1=r1+gamma*Lh'*(Ia\r2);
        r1=Ia*backsolve2(r1,m);
        r1=backsolve(r1,m);

        r2=(Ia\(Lh*r1))-gamma*(Ia\r2);
        z=[r1/sqrt(gamma);r2];
    otherwise
        z=r; %no preconditioning
end
end

function z1=backsolve(r1,m)
global Pre gamma
z1=r1; E=speye(m)/sqrt(gamma);
z1(1:m)=(E/sqrt(2)+Pre.TT)\r1(1:m); % solve 1st block
r1(m+1:2*m)=r1(m+1:2*m)+(2/Pre.dt^2)*z1(1:m);
r1(2*m+1:3*m)=r1(2*m+1:3*m)-Pre.TT*z1(1:m);

for k=2:Pre.nt-2
    idx=((k-1)*m+1:k*m)';
    z1(idx)=(E+Pre.TT)\r1(idx); % solve each block, here TT is tridiagonal matrix
    r1(idx+m)=r1(idx+m)+(2/Pre.dt^2)*z1(idx);
    r1(idx+2*m)=r1(idx+2*m)-Pre.TT*z1(idx);
end

z1(idx+m)=(E+Pre.TT)\r1(idx+m);%last solve
r1(idx+2*m)=r1(idx+2*m)+(2/Pre.dt^2)*z1(idx+m);
z1(idx+2*m)=(E/sqrt(2)+Pre.TT)\r1(idx+2*m);
end

function z1=backsolve2(r1,m)
global Pre gamma
N=length(r1);
z1=r1; E=speye(m)/sqrt(gamma);
z1(N-m+1:N)=(E/sqrt(2)+Pre.TT)\r1(N-m+1:N); % solve 1st block
r1(N-2*m+1:N-m)=r1(N-2*m+1:N-m)+(2/Pre.dt^2)*z1(N-m+1:N);
r1(N-3*m+1:N-2*m)=r1(N-3*m+1:N-2*m)-Pre.TT*z1(N-m+1:N);
%N=Pre.nt*m
for k=Pre.nt-1:-1:3
    idx=((k-1)*m+1:k*m)';
    z1(idx)=(E+Pre.TT)\r1(idx); % solve each block, here TT is tridiagonal matrix
    r1(idx-m)=r1(idx-m)+(2/Pre.dt^2)*z1(idx);
    r1(idx-2*m)=r1(idx-2*m)-Pre.TT*z1(idx);
end
z1(idx-m)=(E+Pre.TT)\r1(idx-m);%last solve
r1(idx-2*m)=r1(idx-2*m)+(2/Pre.dt^2)*z1(idx-m);
z1(idx-2*m)=(E/sqrt(2)+Pre.TT)\r1(idx-2*m);
end

function [A,B,C,K]=discretizeSystem(nx,nt,T,scheme)
%define the whole system using Shulin's kronecker formulas
dt=T/nt;
h=1/nx; m = nx-1; %m for inner points
N=m*(nt);%whole system size,
e_t=ones(nt,1); %e_2=ones(N_2,1);

B=blkdiag(speye(m)/2,speye(N-m)); %Ia
C=blkdiag(speye(N-m),speye(m)/2); %Ib
I=speye(m);
L=I-0.5*(dt^2/h^2)*gallery('tridiag',m,1,-2,1); % central finite difference for second derivative in space

% A1=spdiags([e_t -2*e_t e_t]/dt^2,[-2:0],nt,nt);
% A2=spdiags([e_t e_t]/2,[-2 0],nt,nt);
% E=speye(m);
% A=kron(A1,E)-kron(A2,L);
% A1_C=A1; A1_C(1,end-1)=1/dt^2; A1_C(1,end)=-2/dt^2;A1_C(2,end)=1/dt^2;
% A2_C=A2; A2_C(1,end)=1/2;
% PA=kron(A1_C,E)-kron(A2_C,L);
A0=spdiags([e_t e_t],[-2 0],nt,nt);
B0=spdiags([e_t],[-1],nt,nt);
%construct circulant block of L
E=A0; E(1,end-1)=1; E(2,end)=1;
F=B0; F(1,end)=1;
A=(kron(A0,L)-kron(B0,2*I))/dt^2;
K=(kron(E,L)-kron(F,2*I))/dt^2;
end
